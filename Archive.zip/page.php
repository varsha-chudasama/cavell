


<?php


// include_once('templates/parts/faq.php');
//include_once('templates/parts/content_block/content-block-dynamic.php');
//include_once('templates/parts/page-double-column.php');
//include_once('templates/parts/page-single-column.php');
//include_once('templates/parts/page-sidebar.php');
//include_once('templates/parts/filters/filter-2.php');
//include_once('templates/parts/filters/filter-1.php');
//include_once('templates/parts/footers/footer-2.php');
//include_once('templates/parts/footers/footer-1.php');
//include_once('templates/parts/instagram-block.php');
//include_once('templates/parts/content_block/content-block-text-slider.php');
//include_once('templates/parts/vacancy-block.php');
//include_once('templates/parts/header_banners/header_banner_1.php');
//include_once('templates/parts/header_banners/header_banner_2.php');
//include_once('templates/parts/header_banners/header_banner_3.php');
//include_once('templates/parts/content_block/content-block-banner.php');
//include_once('templates/parts/content_block/content-block-multiple.php');
//include_once('templates/parts/logo-slider.php');
//include_once('templates/parts/process-block.php');
//include_once('templates/parts/related_items/related-items-slider.php');
//include_once('templates/parts/related_items/related-items-1.php');
//include_once('templates/parts/related_items/related-items-2.php');
//include_once('templates/parts/content_block/content-block-image.php');
//include_once('templates/parts/content_block/content-block-image-slider.php');
//include_once('templates/parts/gallery-slider.php');
//include_once('templates/parts/video-section.php');
//include_once('templates/parts/useful-links.php');
//include_once('templates/parts/content_block/content-block-slider.php');
//include_once('templates/parts/content_block/content-popup.php');
//include_once('templates/parts/content_block/content-block-columns.php');
//include_once('templates/parts/history-block.php');
//include_once('templates/parts/contact-form.php');
?>
