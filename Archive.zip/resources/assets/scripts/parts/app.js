export class App {
  init() {
 
  }

}
