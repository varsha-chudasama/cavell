
  <div class="row">
    <div class="col-md-8 col-md-offset-2 text-center">

        <h1 class=" text-center">We're sorry - something has gone wrong.</h1>

          <p class="bold">What could have caused this?</p>
          <p >
            Well, something technical went wrong on our site.<br>
            We might have removed the page.<br>
            Or the link you clicked might be old and does not work anymore.<br>
            Or you might have accidentally typed the wrong URL in the address bar.
          </p>
          <p class="bold">What can you do?</p>
          <p>
            We could take you back to the <strong><a href="/"> home page</a></strong>.<br>
          </p>

    </div>
  </div>





